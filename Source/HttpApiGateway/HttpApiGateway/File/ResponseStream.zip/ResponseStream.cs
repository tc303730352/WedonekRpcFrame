﻿using HttpApiExtend.Interface;
using System.IO;

namespace HttpApiExtend
{
        internal class ResponseStream : IResponseStream
        {
                private Stream _Stream = null;
                public ResponseStream(Stream stream, string fileName)
                {
                        this._Stream = stream;
                        this.FileName = fileName;
                        this.Extension = Path.GetExtension(fileName);
                }

                public string Extension { get; }
                public bool IsExists { get; } = true;
                public bool IsBinary { get; set; }

                public string FileName { get; }

              

                public Stream Open()
                {
                        return _Stream;
                }
        }
}
